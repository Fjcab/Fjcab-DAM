package com.example.ligasfirebase.db.model

import java.io.Serializable

class Liga (var idLeague: String? = null,
                var strLeague: String? = null,
                val strSport: String? = null)
    :Serializable {

    }