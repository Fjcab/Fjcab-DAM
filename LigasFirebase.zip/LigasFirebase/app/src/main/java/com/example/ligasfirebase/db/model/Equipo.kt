package com.example.ligasfirebase.db.model

import java.io.Serializable

class Equipo (val strTeam: String? = null, val strBadge: String? = null): Serializable {
}